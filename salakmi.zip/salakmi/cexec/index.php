<?php

include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id='exec';

echo "<div class=\"main\">";
include_once "../desain/header.php";

echo "Bejo membuat sebuah fungsi di websitenya untuk melakukan ping ke server lain. 
Dengan kemampuan pas pasan seperti inilah fungsi yang ia buat.";

echo "<form name=\"ping\" action=\"#\" method=\"post\">
            <p>
                Enter an IP address:
                <input type=\"text\" name=\"ip\" size=\"30\">
                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
            </p>\n
            </form>";

if( isset( $_POST[ 'Submit' ]  ) ) {
    
    $target = $_REQUEST[ 'ip' ];

    
    if( stristr( php_uname( 's' ), 'Windows NT' ) ) {
        // Windows
        $cmd = shell_exec( 'ping  ' . $target );
    }
    else {
        // *nix
        $cmd = shell_exec( 'ping  -c 4 ' . $target );
    }

    
    echo "<pre>{$cmd}</pre>";
}

include_once "../desain/tombol.php";
echo "</div>";
?> 

<!--<div style="position:absolute;bottom:0;right:10px;">asd</div>-->