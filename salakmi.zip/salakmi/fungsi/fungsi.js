function popUp(URL) {
	window.open(URL, '" Salakmi Lab"', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=500,height=500,left = 540,top = 250');
}