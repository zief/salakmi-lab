<?php
//include"../konfig/koneksi.php";

include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id ='sqli';
echo "<div class=\"main\" style=\"height: 100%;\">";
echo "<div class=\"main2\">";
include "../desain/header.php";

echo "<form action=\"#\" method=\"GET\">
            <p>
                User id:
                <input type=\"text\" name=\"id\" size=\"30\">
                <input type=\"submit\" name=\"Submit\" value=\"Submit\">
            </p>\n
            </form>";

if( isset( $_GET[ 'Submit' ] ) ) {

	$id = $_GET['id'];

$db = new mysqli('localhost', 'root', '', 'salakmi');

if($db->connect_errno > 0){
    die('Nggak bisa konek ke database [' . $db->connect_error . ']');
}

$sql = <<<SQL
    SELECT *
    FROM `nama`
    WHERE `id` = '$id'
SQL;
?>

<table border=0>
 <tr>
 	<th> Nama </th>
 	<th> Alamat </th>

<?php

if(!$result = $db->query($sql)){
    die('Ada eror di query [' . $db->error . ']');
}


while($row = $result->fetch_assoc()){
    echo '<tr> <td>'.$row['nama'] . '</td> <td>' . $row['alamat'] . '</td>';
}

$result->free();
$db->close();



}

include_once "../desain/tombol.php";

echo "</div>";
echo "<div class=\"footer\"> 
  <p>Lab ini bersifat Open Source. Beberapa potongan kode berasal dari kode kode php open source juga.</p>
</div>";