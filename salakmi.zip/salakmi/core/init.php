<?php

require_once "fungsi/koneksi.php";
require_once "fungsi/tutor.php";

?>