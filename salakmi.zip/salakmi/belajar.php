<?php

require_once "core/init.php";

echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"/salakmi/css/styleku.css\">";
echo "<link rel=\"stylesheet\" href=\"/salakmi/fa/css/font-awesome.min.css\">";
?>
<div id="mySidenav" class="sidenav">
   <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
   <a href="belajar.php?kode=scan" class="fa fa-bug"> Scanning Kerentanan</a>
  <a href="belajar.php?kode=exec" class="fa fa-bug"> Command Execution</a>
    <a href="belajar.php?kode=rlfi" class="fa fa-bug"> RFI / LFI </a>
      <a href="belajar.php?kode=phpi" class="fa fa-bug"> PHP Injection </a>
    <a href="belajar.php?kode=sqli" class="fa fa-bug"> SQL Injection </a>
    <a href="belajar.php?kode=upload" class="fa fa-bug"> Upload file </a>
 
    
    
  
</div>

<script>
function buka() {
  var status = 0;
  if(status===1){
    closeNav();
  }
  else{
    openNav();
  }
}
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    status=1;
    
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    status = 0;
}
</script>
<?php

echo "<div class=\"main\">";


include_once "desain/header.php";


 


if(isset($_GET['kode'])){

  $kode = $_GET['kode'];
  $judul ='';
  $konten = '';

  $tutor = tampilkan_tutor($kode);

   while($row= mysqli_fetch_assoc($tutor)){
     $judul = $row['judul'];
     $konten = $row['isi'];

    
  }

}else
{
  $kode = '';
  $judul = 'Tutorial';
  $konten = 'Halaman ini berisi tutorial untuk melakukan serangan. Diharapkan untuk mencoba terlebih dahulu.';
}



?>
 
<p id="judul">
   <?=$judul; ?>
</p>

<p id="konten">
   <?=$konten; ?>
</p>



</div>