<?php
include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id='phpi';

echo "<div class=\"main\" >";
include_once "../desain/header.php";
?>
<p> Halaman ini akan merefleksikan pesan yang kamu tulis di url, klik  <a href="<?php echo($_SERVER["SCRIPT_NAME"]);?>?pesan=test"> Pesan </a>...</p>

<?php

if(isset($_REQUEST["pesan"]))
{
	@eval ("echo " .$_REQUEST["pesan"]. ";");
}

include_once "../desain/tombol.php";
echo "</div>";

?>