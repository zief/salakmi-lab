<?php

include_once "desain/sider.php";
echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"/salakmi/css/styleku.css\">";
echo "<link rel=\"stylesheet\" href=\"/salakmi/fa/css/font-awesome.min.css\">";

echo "<div class=\"main\">";
echo "<div class=\"main2\" >";
include_once "desain/header.php";
?>


<div class="col-9">
  <h1>SalakMI Lab</h1>
  <p>Adalah Web yang di desain untuk di jadikan Lab hacking. Web ini di desain untuk di serang</p>
  <p> Di buat untuk belajar kawan kawan yang tetarik di dunia ethical hacking</p>
</div>

<div class="col-3 right">
  <div class="aside">
    <h2>Apa itu salakMI Lab?</h2>
    <p>Adalah Lab hacking Web</p>
    <h2> Dibuat untuk siapa?</h2>
    <p> Semua yang belajar hacking di luar sana. Dan terkhusus komunitas hacking dan mahasiswa Amikom yang tertarik di bidang penetration testing dan Digital Forensics</p>
    <h2> Siapa pembuatnya?</h2>
    <p>Zifor Syuhada<br>
     CEO of SalakMI </p>
  </div>
</div>

</div>
</div>
<div class="footer2">
<div class="footer"> 
  <p>Ini footer :D - Becanda.. Tetap semangat dan terus belajar</p>
  <p> Hint: gunakan nikto terlebih dahulu untuk melakukan scanning, mungkin akan ada hal bermanfaat yang bisa kamu dapatkan </p>
</div>
</div>



</body>
</html> 
