<?php
include_once "../desain/sider.php";
include_once "../desain/setcss.php";

$id = 'rlfi';

echo "<div class=\"main\" style=\"height: 100%;\">";
include_once "../desain/header.php";

$status = "";

echo "<form name=\"rfli\" action=\"#\" method=\"get\">
            <p>
                Status:
                <select name=\"status\">
             	    <option value=\"jomblo.php\"> Jomblo </option>
            		<option value=\"single.php\"> Single </option>
            		<option value=\"complicated.php\"> Complicated </option>
            	</select>

             <button type=\"submit\" name=\"action\" value=\"go\"> Go </button>
             </form>";

if(isset($_GET["status"]))
	{
		$status = $_GET["status"];  
		include($status);
	}

include_once "../desain/tombol.php";

echo "</div>";

?>