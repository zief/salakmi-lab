<?php echo "<div style=\"position:fixed;bottom:10px;right:15%;\">
<form> <input type=\"submit\" class=\"btn fa-input\" value=\"&#xf002; Tampil Source\" onclick=\"javascript:popUp( '/salakmi/tampil_source.php?id=$id')\"> </form>

</div>";

//<input type=\"submit\" name=\"Submit\" class=\"btn fa-input\" value=\"&#xf002; input\"></font>

?>