<div class="footer">
  <p>Lab ini bersifat Open Source. Beberapa potongan kode berasal dari kode kode php open source juga.</p>
</div>